const signInButton = document.getElementById('signIn');
const signUpButton = document.getElementById('signUp');
const authContainer = document.querySelector('.auth-container');

signInButton.addEventListener('click', () => {
    authContainer.classList.remove('right-panel-active');
});

signUpButton.addEventListener('click', () => {
    authContainer.classList.add('right-panel-active');
});

document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("currentUser")) {
        window.location.href = "dashboard.html";
    }
});

function login(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Dummy authentication logic for demonstration
    if (username === "user" && password === "password") {
        localStorage.setItem("currentUser", username);
        window.location.href = "dashboard.html";
    } else {
        document.getElementById('error-message').textContent = "Invalid username or password";
    }
}

function signUp(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const username = document.getElementById('new-username').value;
    const password = document.getElementById('new-password').value;
    
    // Dummy sign-up logic for demonstration
    localStorage.setItem("currentUser", username);
    window.location.href = "dashboard.html";
}
